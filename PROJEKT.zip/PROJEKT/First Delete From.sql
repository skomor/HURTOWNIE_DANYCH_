use Coronavirus
delete from GEOGRAFIA_DIM
delete from FILE_CORONA_REC_STAGE
delete from FILE_CORONA_STAGE
delete from CZAS_DIM